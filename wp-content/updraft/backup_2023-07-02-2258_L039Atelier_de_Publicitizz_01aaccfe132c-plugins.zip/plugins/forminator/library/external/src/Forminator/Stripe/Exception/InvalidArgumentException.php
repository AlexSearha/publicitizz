<?php

namespace Forminator\Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
