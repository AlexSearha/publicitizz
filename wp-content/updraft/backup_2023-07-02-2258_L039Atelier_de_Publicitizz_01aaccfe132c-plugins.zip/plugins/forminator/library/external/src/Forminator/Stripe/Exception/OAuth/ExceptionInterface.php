<?php

namespace Forminator\Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \Forminator\Stripe\Exception\ExceptionInterface
{
}
