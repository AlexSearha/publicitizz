<div id="acx_csma_help_page"><div style='background: none repeat scroll 0% 0% white; height: 100%; display: inline-block; padding: 8px; margin-top: 5px; border-radius: 15px; min-height: 450px; width: 98%;'>
<h2 style="text-align:center;"><?php _e("Coming Soon/Maintenance From Acurax- Wordpress Plugin - Help/Support",ACX_CSMA_WP_SLUG); ?></h2>
<p style="text-align:center;"><?php _e("Thank you for using Coming Soon/Maintenance From Acurax Plugin",ACX_CSMA_WP_SLUG); ?></p>
<h3 style="text-align:center;"><a href="https://wordpress.org/plugins/coming-soon-maintenance-mode-from-acurax/faq/" target="_blank" class="button"><?php _e("Click here to open the FAQ and Help Page",ACX_CSMA_WP_SLUG);?></a></h3>
</div> <!-- acx_help_page -->
</div> 