jQuery(document).ready(function($)
{
	// Template 1
	jQuery('#acx_csma_logo_text_color1_div').hide();
	jQuery('#acx_csma_logo_text_color1_div').farbtastic('#acx_csma_logo_text_color1');
	jQuery('#acx_csma_logo_text_color1').click(function(){jQuery('#acx_csma_logo_text_color1_div').slideDown()});
	jQuery('#acx_csma_logo_text_color1').blur(function(){jQuery('#acx_csma_logo_text_color1_div').slideUp()});
	
	jQuery('#acx_csma_title_color1_div').hide();
	jQuery('#acx_csma_title_color1_div').farbtastic('#acx_csma_title_color1');
	jQuery('#acx_csma_title_color1').click(function(){jQuery('#acx_csma_title_color1_div').slideDown()});
	jQuery('#acx_csma_title_color1').blur(function(){jQuery('#acx_csma_title_color1_div').slideUp()});
	
	jQuery('#acx_csma_subtitle_color1_div').hide();
	jQuery('#acx_csma_subtitle_color1_div').farbtastic('#acx_csma_subtitle_color1');
	jQuery('#acx_csma_subtitle_color1').click(function(){jQuery('#acx_csma_subtitle_color1_div').slideDown()});
	jQuery('#acx_csma_subtitle_color1').blur(function(){jQuery('#acx_csma_subtitle_color1_div').slideUp()});
			
	jQuery('#acx_csma_inside_bg_color1_div').hide();
	jQuery('#acx_csma_inside_bg_color1_div').farbtastic('#acx_csma_inside_bg_color1');
	jQuery('#acx_csma_inside_bg_color1').click(function(){jQuery('#acx_csma_inside_bg_color1_div').slideDown()});
	jQuery('#acx_csma_inside_bg_color1').blur(function(){jQuery('#acx_csma_inside_bg_color1_div').slideUp()});
	
	jQuery('#acx_csma_inside_title_color1_div').hide();
	jQuery('#acx_csma_inside_title_color1_div').farbtastic('#acx_csma_inside_title_color1');
	jQuery('#acx_csma_inside_title_color1').click(function(){jQuery('#acx_csma_inside_title_color1_div').slideDown()});
	jQuery('#acx_csma_inside_title_color1').blur(function(){jQuery('#acx_csma_inside_title_color1_div').slideUp()});
	
	jQuery('#acx_csma_timer_bg_color1_div').hide();
	jQuery('#acx_csma_timer_bg_color1_div').farbtastic('#acx_csma_timer_bg_color1');	
	jQuery('#acx_csma_timer_bg_color1').click(function(){jQuery('#acx_csma_timer_bg_color1_div').slideDown()});
	jQuery('#acx_csma_timer_bg_color1').blur(function(){jQuery('#acx_csma_timer_bg_color1_div').slideUp()});
	
	jQuery('#acx_csma_timer_iptext_color1_div').hide();
	jQuery('#acx_csma_timer_iptext_color1_div').farbtastic('#acx_csma_timer_iptext_color1');	
	jQuery('#acx_csma_timer_iptext_color1').click(function(){jQuery('#acx_csma_timer_iptext_color1_div').slideDown()});
	jQuery('#acx_csma_timer_iptext_color1').blur(function(){jQuery('#acx_csma_timer_iptext_color1_div').slideUp()});
	
	
	jQuery('#acx_csma_timer_input_bg_color1_div').hide();
	jQuery('#acx_csma_timer_input_bg_color1_div').farbtastic('#acx_csma_timer_input_bg_color1');	
	jQuery('#acx_csma_timer_input_bg_color1').click(function(){jQuery('#acx_csma_timer_input_bg_color1_div').slideDown()});
	jQuery('#acx_csma_timer_input_bg_color1').blur(function(){jQuery('#acx_csma_timer_input_bg_color1_div').slideUp()});
	
	jQuery('#acx_csma_timer_head_color1_div').hide();
	jQuery('#acx_csma_timer_head_color1_div').farbtastic('#acx_csma_timer_head_color1');	
	jQuery('#acx_csma_timer_head_color1').click(function(){jQuery('#acx_csma_timer_head_color1_div').slideDown()});
	jQuery('#acx_csma_timer_head_color1').blur(function(){jQuery('#acx_csma_timer_head_color1_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_bg_color1_div').hide();
	jQuery('#acx_csma_subscribe_bg_color1_div').farbtastic('#acx_csma_subscribe_bg_color1');	
	jQuery('#acx_csma_subscribe_bg_color1').click(function(){jQuery('#acx_csma_subscribe_bg_color1_div').slideDown()});
	jQuery('#acx_csma_subscribe_bg_color1').blur(function(){jQuery('#acx_csma_subscribe_bg_color1_div').slideUp()});
	
	
	jQuery('#acx_csma_subscribe_btn_text_color1_div').hide();
	jQuery('#acx_csma_subscribe_btn_text_color1_div').farbtastic('#acx_csma_subscribe_btn_text_color1');	
	jQuery('#acx_csma_subscribe_btn_text_color1').click(function(){jQuery('#acx_csma_subscribe_btn_text_color1_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_text_color1').blur(function(){jQuery('#acx_csma_subscribe_btn_text_color1_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_color1_div').hide();
	jQuery('#acx_csma_subscribe_btn_color1_div').farbtastic('#acx_csma_subscribe_btn_color1');	
	jQuery('#acx_csma_subscribe_btn_color1').click(function(){jQuery('#acx_csma_subscribe_btn_color1_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_color1').blur(function(){jQuery('#acx_csma_subscribe_btn_color1_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_hover_color1_div').hide();
	jQuery('#acx_csma_subscribe_btn_hover_color1_div').farbtastic('#acx_csma_subscribe_btn_hover_color1');	
	jQuery('#acx_csma_subscribe_btn_hover_color1').click(function(){jQuery('#acx_csma_subscribe_btn_hover_color1_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_hover_color1').blur(function(){jQuery('#acx_csma_subscribe_btn_hover_color1_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor1_div').hide();
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor1_div').farbtastic('#acx_csma_subscribe_btn_hover_bgcolor1');	
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor1').click(function(){jQuery('#acx_csma_subscribe_btn_hover_bgcolor1_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor1').blur(function(){jQuery('#acx_csma_subscribe_btn_hover_bgcolor1_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_title_color1_div').hide();
	jQuery('#acx_csma_subscribe_title_color1_div').farbtastic('#acx_csma_subscribe_title_color1');	
	jQuery('#acx_csma_subscribe_title_color1').click(function(){jQuery('#acx_csma_subscribe_title_color1_div').slideDown()});
	jQuery('#acx_csma_subscribe_title_color1').blur(function(){jQuery('#acx_csma_subscribe_title_color1_div').slideUp()});
	
	jQuery('#acx_csma_footer_bgcolor1_div').hide();
	jQuery('#acx_csma_footer_bgcolor1_div').farbtastic('#acx_csma_footer_bgcolor1');	
	jQuery('#acx_csma_footer_bgcolor1').click(function(){jQuery('#acx_csma_footer_bgcolor1_div').slideDown()});
	jQuery('#acx_csma_footer_bgcolor1').blur(function(){jQuery('#acx_csma_footer_bgcolor1_div').slideUp()});
	
	jQuery('#acx_csma_footer_text_color1_div').hide();
	jQuery('#acx_csma_footer_text_color1_div').farbtastic('#acx_csma_footer_text_color1');	
	jQuery('#acx_csma_footer_text_color1').click(function(){jQuery('#acx_csma_footer_text_color1_div').slideDown()});
	jQuery('#acx_csma_footer_text_color1').blur(function(){jQuery('#acx_csma_footer_text_color1_div').slideUp()});	
	if(jQuery("#acx_csma_footer_gdprcolor1").length > 0)
	{
	jQuery('#acx_csma_footer_gdprcolor1_div').hide();
	jQuery('#acx_csma_footer_gdprcolor1_div').farbtastic('#acx_csma_footer_gdprcolor1');	
	jQuery('#acx_csma_footer_gdprcolor1').click(function(){jQuery('#acx_csma_footer_gdprcolor1_div').slideDown()});
	jQuery('#acx_csma_footer_gdprcolor1').blur(function(){jQuery('#acx_csma_footer_gdprcolor1_div').slideUp()});
	}
	if(jQuery("#acx_csma_footer_gdpr_hovercolor1").length > 0)
	{
	jQuery('#acx_csma_footer_gdpr_hovercolor1_div').hide();
	jQuery('#acx_csma_footer_gdpr_hovercolor1_div').farbtastic('#acx_csma_footer_gdpr_hovercolor1');	
	jQuery('#acx_csma_footer_gdpr_hovercolor1').click(function(){jQuery('#acx_csma_footer_gdpr_hovercolor1_div').slideDown()});
	jQuery('#acx_csma_footer_gdpr_hovercolor1').blur(function(){jQuery('#acx_csma_footer_gdpr_hovercolor1_div').slideUp()});
	}
	// Template 2
	jQuery('#acx_csma_logo_text_color2_div').hide();
	jQuery('#acx_csma_logo_text_color2_div').farbtastic('#acx_csma_logo_text_color2');
	jQuery('#acx_csma_logo_text_color2').click(function(){jQuery('#acx_csma_logo_text_color2_div').slideDown()});
	jQuery('#acx_csma_logo_text_color2').blur(function(){jQuery('#acx_csma_logo_text_color2_div').slideUp()});
	
	jQuery('#acx_csma_logo_bg_color2_div').hide();
	jQuery('#acx_csma_logo_bg_color2_div').farbtastic('#acx_csma_logo_bg_color2');
	jQuery('#acx_csma_logo_bg_color2').click(function(){jQuery('#acx_csma_logo_bg_color2_div').slideDown()});
	jQuery('#acx_csma_logo_bg_color2').blur(function(){jQuery('#acx_csma_logo_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_bg_color2_div').hide();
	jQuery('#acx_csma_bg_color2_div').farbtastic('#acx_csma_bg_color2');
	jQuery('#acx_csma_bg_color2').click(function(){jQuery('#acx_csma_bg_color2_div').slideDown()});
	jQuery('#acx_csma_bg_color2').blur(function(){jQuery('#acx_csma_bg_color2_div').slideUp()});

	jQuery('#acx_csma_title_color2_div').hide();
	jQuery('#acx_csma_title_color2_div').farbtastic('#acx_csma_title_color2');	
	jQuery('#acx_csma_title_color2').click(function(){jQuery('#acx_csma_title_color2_div').slideDown()});
	jQuery('#acx_csma_title_color2').blur(function(){jQuery('#acx_csma_title_color2_div').slideUp()});
	
	jQuery('#acx_csma_subtitle_color2_div').hide();
	jQuery('#acx_csma_subtitle_color2_div').farbtastic('#acx_csma_subtitle_color2');	
	jQuery('#acx_csma_subtitle_color2').click(function(){jQuery('#acx_csma_subtitle_color2_div').slideDown()});
	jQuery('#acx_csma_subtitle_color2').blur(function(){jQuery('#acx_csma_subtitle_color2_div').slideUp()});
	
	jQuery('#acx_csma_inside_bg_color2_div').hide();
	jQuery('#acx_csma_inside_bg_color2_div').farbtastic('#acx_csma_inside_bg_color2');	
	jQuery('#acx_csma_inside_bg_color2').click(function(){jQuery('#acx_csma_inside_bg_color2_div').slideDown()});
	jQuery('#acx_csma_inside_bg_color2').blur(function(){jQuery('#acx_csma_inside_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_divider_bg_color2_div').hide();
	jQuery('#acx_csma_divider_bg_color2_div').farbtastic('#acx_csma_divider_bg_color2');	
	jQuery('#acx_csma_divider_bg_color2').click(function(){jQuery('#acx_csma_divider_bg_color2_div').slideDown()});
	jQuery('#acx_csma_divider_bg_color2').blur(function(){jQuery('#acx_csma_divider_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_timer_title_color2_div').hide();
	jQuery('#acx_csma_timer_title_color2_div').farbtastic('#acx_csma_timer_title_color2');	
	jQuery('#acx_csma_timer_title_color2').click(function(){jQuery('#acx_csma_timer_title_color2_div').slideDown()});
	jQuery('#acx_csma_timer_title_color2').blur(function(){jQuery('#acx_csma_timer_title_color2_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_color2_div').hide();
	jQuery('#acx_csma_subscribe_btn_color2_div').farbtastic('#acx_csma_subscribe_btn_color2');	
	jQuery('#acx_csma_subscribe_btn_color2').click(function(){jQuery('#acx_csma_subscribe_btn_color2_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_color2').blur(function(){jQuery('#acx_csma_subscribe_btn_color2_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_bg_color2_div').hide();
	jQuery('#acx_csma_subscribe_btn_bg_color2_div').farbtastic('#acx_csma_subscribe_btn_bg_color2');	
	jQuery('#acx_csma_subscribe_btn_bg_color2').click(function(){jQuery('#acx_csma_subscribe_btn_bg_color2_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_bg_color2').blur(function(){jQuery('#acx_csma_subscribe_btn_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_timer_input_bg_color2_div').hide();
	jQuery('#acx_csma_timer_input_bg_color2_div').farbtastic('#acx_csma_timer_input_bg_color2');	
	jQuery('#acx_csma_timer_input_bg_color2').click(function(){jQuery('#acx_csma_timer_input_bg_color2_div').slideDown()});
	jQuery('#acx_csma_timer_input_bg_color2').blur(function(){jQuery('#acx_csma_timer_input_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_timer_iptext_color2_div').hide();
	jQuery('#acx_csma_timer_iptext_color2_div').farbtastic('#acx_csma_timer_iptext_color2');	
	jQuery('#acx_csma_timer_iptext_color2').click(function(){jQuery('#acx_csma_timer_iptext_color2_div').slideDown()});
	jQuery('#acx_csma_timer_iptext_color2').blur(function(){jQuery('#acx_csma_timer_iptext_color2_div').slideUp()});
	
	jQuery('#acx_csma_timer_head_color2_div').hide();
	jQuery('#acx_csma_timer_head_color2_div').farbtastic('#acx_csma_timer_head_color2');	
	jQuery('#acx_csma_timer_head_color2').click(function(){jQuery('#acx_csma_timer_head_color2_div').slideDown()});
	jQuery('#acx_csma_timer_head_color2').blur(function(){jQuery('#acx_csma_timer_head_color2_div').slideUp()});
	
	jQuery('#acx_csma_desc_text_color2_div').hide();
	jQuery('#acx_csma_desc_text_color2_div').farbtastic('#acx_csma_desc_text_color2');	
	jQuery('#acx_csma_desc_text_color2').click(function(){jQuery('#acx_csma_desc_text_color2_div').slideDown()});
	jQuery('#acx_csma_desc_text_color2').blur(function(){jQuery('#acx_csma_desc_text_color2_div').slideUp()});
	
	jQuery('#acx_csma_desc_content_color2_div').hide();
	jQuery('#acx_csma_desc_content_color2_div').farbtastic('#acx_csma_desc_content_color2');	
	jQuery('#acx_csma_desc_content_color2').click(function(){jQuery('#acx_csma_desc_content_color2_div').slideDown()});
	jQuery('#acx_csma_desc_content_color2').blur(function(){jQuery('#acx_csma_desc_content_color2_div').slideUp()});

	jQuery('#acx_csma_social_bg_color2_div').hide();
	jQuery('#acx_csma_social_bg_color2_div').farbtastic('#acx_csma_social_bg_color2');	
	jQuery('#acx_csma_social_bg_color2').click(function(){jQuery('#acx_csma_social_bg_color2_div').slideDown()});
	jQuery('#acx_csma_social_bg_color2').blur(function(){jQuery('#acx_csma_social_bg_color2_div').slideUp()});
	
	jQuery('#acx_csma_social_link_color2_div').hide();
	jQuery('#acx_csma_social_link_color2_div').farbtastic('#acx_csma_social_link_color2');	
	jQuery('#acx_csma_social_link_color2').click(function(){jQuery('#acx_csma_social_link_color2_div').slideDown()});
	jQuery('#acx_csma_social_link_color2').blur(function(){jQuery('#acx_csma_social_link_color2_div').slideUp()});
	if(jQuery("#acx_csma_footer_gdprcolor2").length > 0)
	{
	jQuery('#acx_csma_footer_gdprcolor2_div').hide();
	jQuery('#acx_csma_footer_gdprcolor2_div').farbtastic('#acx_csma_footer_gdprcolor2');	
	jQuery('#acx_csma_footer_gdprcolor2').click(function(){jQuery('#acx_csma_footer_gdprcolor2_div').slideDown()});
	jQuery('#acx_csma_footer_gdprcolor2').blur(function(){jQuery('#acx_csma_footer_gdprcolor2_div').slideUp()});
	}
	if(jQuery("#acx_csma_footer_gdpr_hovercolor2").length > 0)
	{
	jQuery('#acx_csma_footer_gdpr_hovercolor2_div').hide();
	jQuery('#acx_csma_footer_gdpr_hovercolor2_div').farbtastic('#acx_csma_footer_gdpr_hovercolor2');	
	jQuery('#acx_csma_footer_gdpr_hovercolor2').click(function(){jQuery('#acx_csma_footer_gdpr_hovercolor2_div').slideDown()});
	jQuery('#acx_csma_footer_gdpr_hovercolor2').blur(function(){jQuery('#acx_csma_footer_gdpr_hovercolor2_div').slideUp()});
	}
	
	// Template 3
	jQuery('#acx_csma_logo_text_color3_div').hide();
	jQuery('#acx_csma_logo_text_color3_div').farbtastic('#acx_csma_logo_text_color3');
	jQuery('#acx_csma_logo_text_color3').click(function(){jQuery('#acx_csma_logo_text_color3_div').slideDown()});
	jQuery('#acx_csma_logo_text_color3').blur(function(){jQuery('#acx_csma_logo_text_color3_div').slideUp()});
	
	jQuery('#acx_csma_title_color3_div').hide();
	jQuery('#acx_csma_title_color3_div').farbtastic('#acx_csma_title_color3');	
	jQuery('#acx_csma_title_color3').click(function(){jQuery('#acx_csma_title_color3_div').slideDown()});
	jQuery('#acx_csma_title_color3').blur(function(){jQuery('#acx_csma_title_color3_div').slideUp()});
	
	jQuery('#acx_csma_subtitle_color3_div').hide();
	jQuery('#acx_csma_subtitle_color3_div').farbtastic('#acx_csma_subtitle_color3');	
	jQuery('#acx_csma_subtitle_color3').click(function(){jQuery('#acx_csma_subtitle_color3_div').slideDown()});
	jQuery('#acx_csma_subtitle_color3').blur(function(){jQuery('#acx_csma_subtitle_color3_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_title_color3_div').hide();
	jQuery('#acx_csma_subscribe_title_color3_div').farbtastic('#acx_csma_subscribe_title_color3');	
	jQuery('#acx_csma_subscribe_title_color3').click(function(){jQuery('#acx_csma_subscribe_title_color3_div').slideDown()});
	jQuery('#acx_csma_subscribe_title_color3').blur(function(){jQuery('#acx_csma_subscribe_title_color3_div').slideUp()}); 
	
	
	jQuery('#acx_csma_subscribe_btn_text_color3_div').hide();
	jQuery('#acx_csma_subscribe_btn_text_color3_div').farbtastic('#acx_csma_subscribe_btn_text_color3');	
	jQuery('#acx_csma_subscribe_btn_text_color3').click(function(){jQuery('#acx_csma_subscribe_btn_text_color3_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_text_color3').blur(function(){jQuery('#acx_csma_subscribe_btn_text_color3_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_color3_div').hide();
	jQuery('#acx_csma_subscribe_btn_color3_div').farbtastic('#acx_csma_subscribe_btn_color3');	
	jQuery('#acx_csma_subscribe_btn_color3').click(function(){jQuery('#acx_csma_subscribe_btn_color3_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_color3').blur(function(){jQuery('#acx_csma_subscribe_btn_color3_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_hover_color3_div').hide();
	jQuery('#acx_csma_subscribe_btn_hover_color3_div').farbtastic('#acx_csma_subscribe_btn_hover_color3');	
	jQuery('#acx_csma_subscribe_btn_hover_color3').click(function(){jQuery('#acx_csma_subscribe_btn_hover_color3_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_hover_color3').blur(function(){jQuery('#acx_csma_subscribe_btn_hover_color3_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor3_div').hide();
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor3_div').farbtastic('#acx_csma_subscribe_btn_hover_bgcolor3');	
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor3').click(function(){jQuery('#acx_csma_subscribe_btn_hover_bgcolor3_div').slideDown()});
	jQuery('#acx_csma_subscribe_btn_hover_bgcolor3').blur(function(){jQuery('#acx_csma_subscribe_btn_hover_bgcolor3_div').slideUp()});
	
	jQuery('#acx_csma_inside_title_color3_div').hide();
	jQuery('#acx_csma_inside_title_color3_div').farbtastic('#acx_csma_inside_title_color3');	
	jQuery('#acx_csma_inside_title_color3').click(function(){jQuery('#acx_csma_inside_title_color3_div').slideDown()});
	jQuery('#acx_csma_inside_title_color3').blur(function(){jQuery('#acx_csma_inside_title_color3_div').slideUp()});
	
	jQuery('#acx_csma_timer_iptext_color3_div').hide();
	jQuery('#acx_csma_timer_iptext_color3_div').farbtastic('#acx_csma_timer_iptext_color3');	
	jQuery('#acx_csma_timer_iptext_color3').click(function(){jQuery('#acx_csma_timer_iptext_color3_div').slideDown()});
	jQuery('#acx_csma_timer_iptext_color3').blur(function(){jQuery('#acx_csma_timer_iptext_color3_div').slideUp()});
	
	jQuery('#acx_csma_timer_head_color3_div').hide();
	jQuery('#acx_csma_timer_head_color3_div').farbtastic('#acx_csma_timer_head_color3');	
	jQuery('#acx_csma_timer_head_color3').click(function(){jQuery('#acx_csma_timer_head_color3_div').slideDown()});
	jQuery('#acx_csma_timer_head_color3').blur(function(){jQuery('#acx_csma_timer_head_color3_div').slideUp()});
	
	jQuery('#acx_csma_desc_text_color3_div').hide();
	jQuery('#acx_csma_desc_text_color3_div').farbtastic('#acx_csma_desc_text_color3');	
	jQuery('#acx_csma_desc_text_color3').click(function(){jQuery('#acx_csma_desc_text_color3_div').slideDown()});
	jQuery('#acx_csma_desc_text_color3').blur(function(){jQuery('#acx_csma_desc_text_color3_div').slideUp()});
	
	jQuery('#acx_csma_desc_content_color3_div').hide();
	jQuery('#acx_csma_desc_content_color3_div').farbtastic('#acx_csma_desc_content_color3');	
	jQuery('#acx_csma_desc_content_color3').click(function(){jQuery('#acx_csma_desc_content_color3_div').slideDown()});
	jQuery('#acx_csma_desc_content_color3').blur(function(){jQuery('#acx_csma_desc_content_color3_div').slideUp()});
	
	jQuery('#acx_csma_footer_color3_div').hide();
	jQuery('#acx_csma_footer_color3_div').farbtastic('#acx_csma_footer_color3');	
	jQuery('#acx_csma_footer_color3').click(function(){jQuery('#acx_csma_footer_color3_div').slideDown()});
	jQuery('#acx_csma_footer_color3').blur(function(){jQuery('#acx_csma_footer_color3_div').slideUp()});
	
	jQuery('#acx_csma_social_link_title_color3_div').hide();
	jQuery('#acx_csma_social_link_title_color3_div').farbtastic('#acx_csma_social_link_title_color3');	
	jQuery('#acx_csma_social_link_title_color3').click(function(){jQuery('#acx_csma_social_link_title_color3_div').slideDown()});
	jQuery('#acx_csma_social_link_title_color3').blur(function(){jQuery('#acx_csma_social_link_title_color3_div').slideUp()});
	if(jQuery("#acx_csma_footer_gdprcolor3").length > 0)
	{
	jQuery('#acx_csma_footer_gdprcolor3_div').hide();
	jQuery('#acx_csma_footer_gdprcolor3_div').farbtastic('#acx_csma_footer_gdprcolor3');	
	jQuery('#acx_csma_footer_gdprcolor3').click(function(){jQuery('#acx_csma_footer_gdprcolor3_div').slideDown()});
	jQuery('#acx_csma_footer_gdprcolor3').blur(function(){jQuery('#acx_csma_footer_gdprcolor3_div').slideUp()});
	}
	if(jQuery("#acx_csma_footer_gdpr_hovercolor3").length > 0)
	{
	jQuery('#acx_csma_footer_gdpr_hovercolor3_div').hide();
	jQuery('#acx_csma_footer_gdpr_hovercolor3_div').farbtastic('#acx_csma_footer_gdpr_hovercolor3');	
	jQuery('#acx_csma_footer_gdpr_hovercolor3').click(function(){jQuery('#acx_csma_footer_gdpr_hovercolor3_div').slideDown()});
	jQuery('#acx_csma_footer_gdpr_hovercolor3').blur(function(){jQuery('#acx_csma_footer_gdpr_hovercolor3_div').slideUp()});
	}
  // Template 4
	jQuery('#acx_csma_logo_text_color4_div').hide();
	jQuery('#acx_csma_logo_text_color4_div').farbtastic('#acx_csma_logo_text_color4');
	jQuery('#acx_csma_logo_text_color4').click(function(){jQuery('#acx_csma_logo_text_color4_div').slideDown()});
	jQuery('#acx_csma_logo_text_color4').blur(function(){jQuery('#acx_csma_logo_text_color4_div').slideUp()});
	
	jQuery('#acx_csma_inside_bg_color4_div').hide();
	jQuery('#acx_csma_inside_bg_color4_div').farbtastic('#acx_csma_inside_bg_color4');
	jQuery('#acx_csma_inside_bg_color4').click(function(){jQuery('#acx_csma_inside_bg_color4_div').slideDown()});
	jQuery('#acx_csma_inside_bg_color4').blur(function(){jQuery('#acx_csma_inside_bg_color4_div').slideUp()});

	jQuery('#acx_csma_title_color4_div').hide();
	jQuery('#acx_csma_title_color4_div').farbtastic('#acx_csma_title_color4');	
	jQuery('#acx_csma_title_color4').click(function(){jQuery('#acx_csma_title_color4_div').slideDown()});
	jQuery('#acx_csma_title_color4').blur(function(){jQuery('#acx_csma_title_color4_div').slideUp()});
	
	jQuery('#acx_csma_timer_iptext_color4_div').hide();
	jQuery('#acx_csma_timer_iptext_color4_div').farbtastic('#acx_csma_timer_iptext_color4');	
	jQuery('#acx_csma_timer_iptext_color4').click(function(){jQuery('#acx_csma_timer_iptext_color4_div').slideDown()});
	jQuery('#acx_csma_timer_iptext_color4').blur(function(){jQuery('#acx_csma_timer_iptext_color4_div').slideUp()});
	
	jQuery('#acx_csma_timer_head_color4_div').hide();
	jQuery('#acx_csma_timer_head_color4_div').farbtastic('#acx_csma_timer_head_color4');	
	jQuery('#acx_csma_timer_head_color4').click(function(){jQuery('#acx_csma_timer_head_color4_div').slideDown()});
	jQuery('#acx_csma_timer_head_color4').blur(function(){jQuery('#acx_csma_timer_head_color4_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_color4_div').hide();
	jQuery('#acx_csma_progress_bar_color4_div').farbtastic('#acx_csma_progress_bar_color4');	
	jQuery('#acx_csma_progress_bar_color4').click(function(){jQuery('#acx_csma_progress_bar_color4_div').slideDown()});
	jQuery('#acx_csma_progress_bar_color4').blur(function(){jQuery('#acx_csma_progress_bar_color4_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_bg_color4_div').hide();
	jQuery('#acx_csma_progress_bar_bg_color4_div').farbtastic('#acx_csma_progress_bar_bg_color4');	
	jQuery('#acx_csma_progress_bar_bg_color4').click(function(){jQuery('#acx_csma_progress_bar_bg_color4_div').slideDown()});
	jQuery('#acx_csma_progress_bar_bg_color4').blur(function(){jQuery('#acx_csma_progress_bar_bg_color4_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_text_color4_div').hide();
	jQuery('#acx_csma_progress_bar_text_color4_div').farbtastic('#acx_csma_progress_bar_text_color4');	
	jQuery('#acx_csma_progress_bar_text_color4').click(function(){jQuery('#acx_csma_progress_bar_text_color4_div').slideDown()});
	jQuery('#acx_csma_progress_bar_text_color4').blur(function(){jQuery('#acx_csma_progress_bar_text_color4_div').slideUp()});
	
	jQuery('#acx_csma_subscription_title_color4_div').hide();
	jQuery('#acx_csma_subscription_title_color4_div').farbtastic('#acx_csma_subscription_title_color4');	
	jQuery('#acx_csma_subscription_title_color4').click(function(){jQuery('#acx_csma_subscription_title_color4_div').slideDown()});
	jQuery('#acx_csma_subscription_title_color4').blur(function(){jQuery('#acx_csma_subscription_title_color4_div').slideUp()});
	
	jQuery('#acx_csma_subscription_btn_color4_div').hide();
	jQuery('#acx_csma_subscription_btn_color4_div').farbtastic('#acx_csma_subscription_btn_color4');	
	jQuery('#acx_csma_subscription_btn_color4').click(function(){jQuery('#acx_csma_subscription_btn_color4_div').slideDown()});
	jQuery('#acx_csma_subscription_btn_color4').blur(function(){jQuery('#acx_csma_subscription_btn_color4_div').slideUp()});
	
	jQuery('#acx_csma_subscription_btn_bg_color4_div').hide();
	jQuery('#acx_csma_subscription_btn_bg_color4_div').farbtastic('#acx_csma_subscription_btn_bg_color4');	
	jQuery('#acx_csma_subscription_btn_bg_color4').click(function(){jQuery('#acx_csma_subscription_btn_bg_color4_div').slideDown()});
	jQuery('#acx_csma_subscription_btn_bg_color4').blur(function(){jQuery('#acx_csma_subscription_btn_bg_color4_div').slideUp()});
	if(jQuery("#acx_csma_footer_gdprcolor4").length > 0)
	{
	jQuery('#acx_csma_footer_gdprcolor4_div').hide();
	jQuery('#acx_csma_footer_gdprcolor4_div').farbtastic('#acx_csma_footer_gdprcolor4');	
	jQuery('#acx_csma_footer_gdprcolor4').click(function(){jQuery('#acx_csma_footer_gdprcolor4_div').slideDown()});
	jQuery('#acx_csma_footer_gdprcolor4').blur(function(){jQuery('#acx_csma_footer_gdprcolor4_div').slideUp()});
	}
	if(jQuery("#acx_csma_footer_gdpr_hovercolor4").length > 0)
	{
	jQuery('#acx_csma_footer_gdpr_hovercolor4_div').hide();
	jQuery('#acx_csma_footer_gdpr_hovercolor4_div').farbtastic('#acx_csma_footer_gdpr_hovercolor4');	
	jQuery('#acx_csma_footer_gdpr_hovercolor4').click(function(){jQuery('#acx_csma_footer_gdpr_hovercolor4_div').slideDown()});
	jQuery('#acx_csma_footer_gdpr_hovercolor4').blur(function(){jQuery('#acx_csma_footer_gdpr_hovercolor4_div').slideUp()});
	}
	// Template 5
	jQuery('#acx_csma_logo_text_color5_div').hide();
	jQuery('#acx_csma_logo_text_color5_div').farbtastic('#acx_csma_logo_text_color5');
	jQuery('#acx_csma_logo_text_color5').click(function(){jQuery('#acx_csma_logo_text_color5_div').slideDown()});
	jQuery('#acx_csma_logo_text_color5').blur(function(){jQuery('#acx_csma_logo_text_color5_div').slideUp()});
	
	jQuery('#acx_csma_bgcolor5_div').hide();
	jQuery('#acx_csma_bgcolor5_div').farbtastic('#acx_csma_bgcolor5');
	jQuery('#acx_csma_bgcolor5').click(function(){jQuery('#acx_csma_bgcolor5_div').slideDown()});
	jQuery('#acx_csma_bgcolor5').blur(function(){jQuery('#acx_csma_bgcolor5_div').slideUp()});

	jQuery('#acx_csma_inside_bg_color5_div').hide();
	jQuery('#acx_csma_inside_bg_color5_div').farbtastic('#acx_csma_inside_bg_color5');
	jQuery('#acx_csma_inside_bg_color5').click(function(){jQuery('#acx_csma_inside_bg_color5_div').slideDown()});
	jQuery('#acx_csma_inside_bg_color5').blur(function(){jQuery('#acx_csma_inside_bg_color5_div').slideUp()});

	jQuery('#acx_csma_title_color5_div').hide();
	jQuery('#acx_csma_title_color5_div').farbtastic('#acx_csma_title_color5');	
	jQuery('#acx_csma_title_color5').click(function(){jQuery('#acx_csma_title_color5_div').slideDown()});
	jQuery('#acx_csma_title_color5').blur(function(){jQuery('#acx_csma_title_color5_div').slideUp()});
	
	jQuery('#acx_csma_timer_iptext_color5_div').hide();
	jQuery('#acx_csma_timer_iptext_color5_div').farbtastic('#acx_csma_timer_iptext_color5');	
	jQuery('#acx_csma_timer_iptext_color5').click(function(){jQuery('#acx_csma_timer_iptext_color5_div').slideDown()});
	jQuery('#acx_csma_timer_iptext_color5').blur(function(){jQuery('#acx_csma_timer_iptext_color5_div').slideUp()});
	
	jQuery('#acx_csma_timer_head_color5_div').hide();
	jQuery('#acx_csma_timer_head_color5_div').farbtastic('#acx_csma_timer_head_color5');	
	jQuery('#acx_csma_timer_head_color5').click(function(){jQuery('#acx_csma_timer_head_color5_div').slideDown()});
	jQuery('#acx_csma_timer_head_color5').blur(function(){jQuery('#acx_csma_timer_head_color5_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_color5_div').hide();
	jQuery('#acx_csma_progress_bar_color5_div').farbtastic('#acx_csma_progress_bar_color5');	
	jQuery('#acx_csma_progress_bar_color5').click(function(){jQuery('#acx_csma_progress_bar_color5_div').slideDown()});
	jQuery('#acx_csma_progress_bar_color5').blur(function(){jQuery('#acx_csma_progress_bar_color5_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_bg_color5_div').hide();
	jQuery('#acx_csma_progress_bar_bg_color5_div').farbtastic('#acx_csma_progress_bar_bg_color5');	
	jQuery('#acx_csma_progress_bar_bg_color5').click(function(){jQuery('#acx_csma_progress_bar_bg_color5_div').slideDown()});
	jQuery('#acx_csma_progress_bar_bg_color5').blur(function(){jQuery('#acx_csma_progress_bar_bg_color5_div').slideUp()});
	
	jQuery('#acx_csma_progress_bar_text_color5_div').hide();
	jQuery('#acx_csma_progress_bar_text_color5_div').farbtastic('#acx_csma_progress_bar_text_color5');	
	jQuery('#acx_csma_progress_bar_text_color5').click(function(){jQuery('#acx_csma_progress_bar_text_color5_div').slideDown()});
	jQuery('#acx_csma_progress_bar_text_color5').blur(function(){jQuery('#acx_csma_progress_bar_text_color5_div').slideUp()});
	
	jQuery('#acx_csma_subscribe_bg_color5_div').hide();
	jQuery('#acx_csma_subscribe_bg_color5_div').farbtastic('#acx_csma_subscribe_bg_color5');	
	jQuery('#acx_csma_subscribe_bg_color5').click(function(){jQuery('#acx_csma_subscribe_bg_color5_div').slideDown()});
	jQuery('#acx_csma_subscribe_bg_color5').blur(function(){jQuery('#acx_csma_subscribe_bg_color5_div').slideUp()});
	
	jQuery('#acx_csma_launch_title_color5_div').hide();
	jQuery('#acx_csma_launch_title_color5_div').farbtastic('#acx_csma_launch_title_color5');	
	jQuery('#acx_csma_launch_title_color5').click(function(){jQuery('#acx_csma_launch_title_color5_div').slideDown()});
	jQuery('#acx_csma_launch_title_color5').blur(function(){jQuery('#acx_csma_launch_title_color5_div').slideUp()});
	
	jQuery('#acx_csma_primary_color3_div').hide();
	jQuery('#acx_csma_primary_color3_div').farbtastic('#acx_csma_primary_color3');	
	jQuery('#acx_csma_primary_color3').click(function(){jQuery('#acx_csma_primary_color3_div').slideDown()});
	jQuery('#acx_csma_primary_color3').blur(function(){jQuery('#acx_csma_primary_color3_div').slideUp()});
	
	jQuery('#acx_csma_secondary_color3_div').hide();
	jQuery('#acx_csma_secondary_color3_div').farbtastic('#acx_csma_secondary_color3');	
	jQuery('#acx_csma_secondary_color3').click(function(){jQuery('#acx_csma_secondary_color3_div').slideDown()});
	jQuery('#acx_csma_secondary_color3').blur(function(){jQuery('#acx_csma_secondary_color3_div').slideUp()});
	
	jQuery('#acx_csma_left_bar_color3_div').hide();
	jQuery('#acx_csma_left_bar_color3_div').farbtastic('#acx_csma_left_bar_color3');	
	jQuery('#acx_csma_left_bar_color3').click(function(){jQuery('#acx_csma_left_bar_color3_div').slideDown()});
	jQuery('#acx_csma_left_bar_color3').blur(function(){jQuery('#acx_csma_left_bar_color3_div').slideUp()});
	
	jQuery('#acx_csma_timer_color3_div').hide();
	jQuery('#acx_csma_timer_color3_div').farbtastic('#acx_csma_timer_color3');	
	jQuery('#acx_csma_timer_color3').click(function(){jQuery('#acx_csma_timer_color3_div').slideDown()});
	jQuery('#acx_csma_timer_color3').blur(function(){jQuery('#acx_csma_timer_color3_div').slideUp()});
	
	if(jQuery("#acx_csma_footer_gdprcolor5").length > 0)
	{
		jQuery('#acx_csma_footer_gdprcolor5_div').hide();
		jQuery('#acx_csma_footer_gdprcolor5_div').farbtastic('#acx_csma_footer_gdprcolor5');	
		jQuery('#acx_csma_footer_gdprcolor5').click(function(){jQuery('#acx_csma_footer_gdprcolor5_div').slideDown()});
		jQuery('#acx_csma_footer_gdprcolor5').blur(function(){jQuery('#acx_csma_footer_gdprcolor5_div').slideUp()});
	}
	if(jQuery("#acx_csma_footer_gdpr_hovercolor5").length > 0)
	{
	jQuery('#acx_csma_footer_gdpr_hovercolor5_div').hide();
	jQuery('#acx_csma_footer_gdpr_hovercolor5_div').farbtastic('#acx_csma_footer_gdpr_hovercolor5');	
	jQuery('#acx_csma_footer_gdpr_hovercolor5').click(function(){jQuery('#acx_csma_footer_gdpr_hovercolor5_div').slideDown()});
	jQuery('#acx_csma_footer_gdpr_hovercolor5').blur(function(){jQuery('#acx_csma_footer_gdpr_hovercolor5_div').slideUp()});
	}
	
	
	
});