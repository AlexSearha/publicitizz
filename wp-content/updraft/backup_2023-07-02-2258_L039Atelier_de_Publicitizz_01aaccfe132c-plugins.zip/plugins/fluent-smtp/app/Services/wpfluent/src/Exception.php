<?php namespace FluentSmtpDb;

class Exception extends \Exception
{

}
