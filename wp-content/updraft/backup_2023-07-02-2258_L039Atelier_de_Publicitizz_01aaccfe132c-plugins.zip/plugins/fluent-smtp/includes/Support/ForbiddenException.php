<?php

namespace FluentMail\Includes\Support;

use Exception;

class ForbiddenException extends Exception
{
    // ...
}
